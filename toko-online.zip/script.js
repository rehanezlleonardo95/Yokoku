
const produk = [
  { id: 1, nama: 'Kaos', harga: 50000 },
  { id: 2, nama: 'Celana', harga: 75000 },
  { id: 3, nama: 'Topi', harga: 30000 }
];

const keranjang = [];

const nomorWhatsApp = '6281234567890';

window.onload = () => {
  const daftarProduk = document.getElementById('produk');
  produk.forEach(item => {
    const div = document.createElement('div');
    div.className = 'item';
    div.innerHTML = \`
      <h3>\${item.nama}</h3>
      <p>Rp \${item.harga}</p>
      <button onclick="tambahKeKeranjang(\${item.id})">Beli</button>
    \`;
    daftarProduk.appendChild(div);
  });

  muatKeranjang();
  tampilkanKeranjang();
};

function tambahKeKeranjang(id) {
  const item = produk.find(p => p.id === id);
  keranjang.push(item);
  simpanKeranjang();
  tampilkanKeranjang();
  alert(\`\${item.nama} ditambahkan ke keranjang.\`);
}

function tampilkanKeranjang() {
  const daftarKeranjang = document.getElementById('daftar-keranjang');
  daftarKeranjang.innerHTML = '';
  let total = 0;

  keranjang.forEach((item, index) => {
    const li = document.createElement('li');
    li.innerHTML = \`
      \${item.nama} - Rp \${item.harga}
      <button onclick="hapusItem(\${index})">Hapus</button>
    \`;
    daftarKeranjang.appendChild(li);
    total += item.harga;
  });

  document.getElementById('total-harga').textContent = \`Total: Rp \${total}\`;
}

function hapusItem(index) {
  keranjang.splice(index, 1);
  simpanKeranjang();
  tampilkanKeranjang();
}

function simpanKeranjang() {
  localStorage.setItem('keranjang', JSON.stringify(keranjang));
}

function muatKeranjang() {
  const data = localStorage.getItem('keranjang');
  if (data) {
    const dataKeranjang = JSON.parse(data);
    keranjang.length = 0;
    dataKeranjang.forEach(item => keranjang.push(item));
  }
}

document.getElementById('checkout-form').addEventListener('submit', function (e) {
  e.preventDefault();

  if (keranjang.length === 0) {
    alert('Keranjang masih kosong!');
    return;
  }

  const nama = document.getElementById('nama').value;
  const alamat = document.getElementById('alamat').value;
  const nohp = document.getElementById('nohp').value;

  let pesan = \`*Pesanan Baru*\n\nNama: \${nama}\nAlamat: \${alamat}\nNo HP: \${nohp}\n\n*Daftar Pesanan:*\n\`;

  let total = 0;
  keranjang.forEach(item => {
    pesan += \`- \${item.nama} - Rp \${item.harga}\n\`;
    total += item.harga;
  });

  pesan += \`\n*Total: Rp \${total}*\`;

  const url = \`https://wa.me/\${nomorWhatsApp}?text=\${encodeURIComponent(pesan)}\`;

  window.open(url, '_blank');

  keranjang.length = 0;
  simpanKeranjang();
  tampilkanKeranjang();
  this.reset();
});
